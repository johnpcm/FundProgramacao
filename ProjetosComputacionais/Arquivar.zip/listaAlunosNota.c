#include "main.h"


main(){


    /*pr� declara��o*/

    int nAlunos, nNotas;


    /*input de tamanhos*/

    printf("Quantos alunos estarao na lista?");
    scanf("%d", &nAlunos);

    printf("\nQuantas notas serao levadas em conta?");
    scanf("%d", &nNotas);


    /*declara��o principal de vetores*/

    int ordenador [nAlunos];
    char listaNomes [nAlunos][16];
    float listaNotas [nAlunos][nNotas+1];


    /*declara��o principal de n�o vetores*/

    int i, k, menor = 1111;


    /*preencher ordenador*/

    for(i = 0; i < nAlunos; i++)
        ordenador [i]=i;

    // ordenador { 0,1,2,3,4,5...nAlunos-1}

    /*cabe�alho do input*/

    printf("\nInsira agora os dados de acordo com o modelo:\n\n Nome do Aluno\n");

    for(i = 1; i <= nNotas; i++)
        printf(" N%d", i);

    printf("\n");


    /*input*/

    for(i = 0; i < nAlunos; i++){
        scanf("%.15s", listaNomes[i]);
        for(k = 1; k <= nNotas; k++){
            scanf("%f", &listaNotas[i][k]);
        }
    }


    /*processar a media*/

    for(i = 0; i < nAlunos; i++){
        listaNotas[i][0] = 0;

        for(k = 1; k <= nNotas; k++)
            listaNotas[i][0] += listaNotas[i][k];

        listaNotas[i][0] /= nNotas;
    }


    /*processar a ordem no vetor*/

    for(i = 0; i < nAlunos; i++){
        menor = 1111;

        for(k = i; k < nAlunos; k++)
            if (listaNotas[k][0] < menor)
                menor = listaNotas[k][0];

        for(k = i; listaNotas[k][0] != menor; k++){}

        ordenador[k] = i;
        ordenador[i] = k;
    }
    for(i = 0; i < nAlunos; i++)
        printf("%d", ordenador[i]);

}
